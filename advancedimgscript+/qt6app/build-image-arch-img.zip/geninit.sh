#!/bin/bash

# Get the original user who called sudo
if [ -n "$SUDO_USER" ]; then
    LOCAL_USER="$SUDO_USER"
else
    LOCAL_USER=$(whoami)
fi

cd "/home/$LOCAL_USER/.config/cmi/build-image-arch-img" && sudo mkinitcpio -c mkinitcpio.conf -g "/home/$LOCAL_USER/.config/cmi/build-image-arch-img/boot/initramfs-x86_64.img"
