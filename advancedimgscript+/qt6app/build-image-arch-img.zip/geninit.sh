#!/bin/bash
cd /home/$USER/.config/cmi/build-image-arch-img && sudo mkinitcpio -c mkinitcpio.conf -g /home/$USER/.config/cmi/build-image-arch-img/boot/initramfs-x86_64.img
