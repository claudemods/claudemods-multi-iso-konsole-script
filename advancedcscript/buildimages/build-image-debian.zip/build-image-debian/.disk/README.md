# penguins_eggs

Volinfo: naked
Image created at: 2025-11-01_0809 using penguins_eggs v. 25.10.30)
repo: [penguins-eggs](https://github.com/penguins-eggs)
blog: [penguins-eggs.net](https://penguins-eggs.net)
author: [Piero Proietti](mailto://piero.proietti@gmail.com)
