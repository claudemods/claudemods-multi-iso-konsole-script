use patch.sh to install 
once installed please edit to your kernel /usr/share/calamares/modules/initcpio.conf 
also edit the same in /etc/calamares/modules/initcpio.conf
to e.g linux-zen linux or leave as linux-cachyos as it is default

### picture of /etc/calamares/modules/initcpio.conf
<img width="1280" height="800" alt="Screenshot_archlinux_2025-10-02_14:05:08" src="https://github.com/user-attachments/assets/ed9e9c9d-4867-4470-917b-4b29f5a0e403" />
