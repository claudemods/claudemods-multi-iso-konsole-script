#!/bin/bash

# Color codes
CYAN='\033[38;2;0;255;255m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

# Function to print colored output
print_green() {
    echo -e "${GREEN}$1${NC}"
}

print_green "Starting Calamares installation and configuration..."

cd /home/$USER/.config/cmi/calamares-files

print_green "Installing Calamares packages..."
sudo pacman -U --noconfirm --overwrite="*" calamares-3.4.0-1-x86_64.pkg.tar.zst calamares-oem-kde-settings-20240616-3-any.pkg.tar calamares-tools-0.1.0-1-any.pkg.tar.zst ckbcomp-1.227-2-any.pkg.tar 2>&1 | while IFS= read -r line; do echo -e "${CYAN}$line${NC}"; done

print_green "Copying Calamares configuration..."
sudo cp -r calamares /etc/ 2>&1 | while IFS= read -r line; do echo -e "${CYAN}$line${NC}"; done

print_green "Copying custom branding..."
sudo cp -r claudemods /usr/share/calamares/branding/ 2>&1 | while IFS= read -r line; do echo -e "${CYAN}$line${NC}"; done

print_green "Extracting extra files..."
sudo unzip -o -q "extras.zip" -d / 2>&1 | while IFS= read -r line; do echo -e "${CYAN}$line${NC}"; done

# Ask user for configuration preference
print_green "Configuration selection:"
echo -e "${GREEN}Choose Calamares mount configuration:${NC}"
echo -e "${GREEN}1) Default configuration${NC}"
echo -e "${GREEN}2) Custom configuration with new mounts and level 22 compression${NC}"
read -p "$(echo -e ${GREEN}"Enter your choice (1 or 2): "${NC})" config_choice

case $config_choice in
    2)
        print_green "Applying custom configuration with new mounts and level 22 compression..."
        sudo cp mount.conf /usr/share/calamares/modules 2>&1 | while IFS= read -r line; do echo -e "${CYAN}$line${NC}"; done
        print_green "Custom configuration applied successfully!"
        ;;
    1|*)
        print_green "Using default Calamares configuration."
        print_green "Skipping custom mount configuration."
        ;;
esac

print_green "Installing Hooks And My Rsync Installer"
cd /home/$USER/.config/cmi && sudo cp -r cmirsyncinstaller /usr/bin 2>&1 | while IFS= read -r line; do echo -e "${CYAN}$line${NC}"; done
cd /home/$USER/.config/cmi/working-hooks-btrfs-ext4 && sudo cp -r * /etc/initcpio 2>&1 | while IFS= read -r line; do echo -e "${CYAN}$line${NC}"; done

sudo rm -rf /usr/share/calamares/branding/manjaro 2>&1 | while IFS= read -r line; do echo -e "${CYAN}$line${NC}"; done

print_green "Calamares installation and configuration completed!"
